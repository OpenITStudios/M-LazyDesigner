# CTF Pillager

Authority: ctf_pillager.bbmodel. One file with tier_1_recruit.png and tier_2_militia.png. Only Tier 1 was approved before the shield revisions; current shield refinements and Tier 2 remain in review. Legacy Pillager Level 2–5 texture entries and the separate Tier 2 model have been removed. Cleaned file was reopened and is now the bound live project.

32x physical 256×128, logical 128×64. Geometry/UV and 13 authored animations unchanged. Both shield textures were subsequently revised at the user's request. Tier 2 uses a transparent red field inside an opaque grey steel perimeter; steel rails now extend inward to provide three physical pixels for bevel, middle plane and shadow. Red must never protrude outside that perimeter. Minecraft alpha-blend integration remains unverified.

## Standing user quality requirements for subsequent CTF work

Explicit user instruction, reiterated 2026-11-16. Apply these requirements together; a later correction does not erase earlier constraints.

- Follow the approved CTF material style and supplied references. Do not substitute an invented style, abstract patches or arbitrary ornament.
- Flat fills and uninterrupted single-colour strips are unacceptable on metal, lamps and other detailed surfaces. Metal needs readable bevel, middle value, shadow, controlled reflection and purposeful joints. Lamps need a bright core, intermediate colours and darker ends. Use deliberate pixel clusters rather than random noise or checker patterns.
- Complete the finishing on front, back, sides, corners and small parts. Do not leave secondary surfaces less finished than the approved front.
- Preserve tidy, readable plate topology while adding shading. Do not trade coherent structure for colour variation, or remove grading while simplifying the design.
- Keep shield fields transparent and all red accents inside the Tier 2 iron perimeter. Preserve Tier 1 versus Tier 2 identity.
- Keep work in ctf_pillager.bbmodel with only the currently user-authorized tiers. Preserve accepted geometry, UV, resolution and animation.
- Before reporting completion, inspect fresh mapped close-ups and whole-model views. Check that grading is visibly readable, not merely present as numeric colour variation. Native save, transaction success and pixel equality do not establish visual acceptance.
- Compare every revision against all accumulated user constraints and check for regressions. Describe only verified changes; do not claim user approval or perfect quality.

Current close-up: shield-tier-2-detail.png. Next: user review of current shield finishing; no new tier is authorized.

Tier 1 shield design locked by user: restore original red outline, short paired indicators and original alpha silhouette; grading/shading only, no Tier 2 motifs or added hardware. Current Tier 1 shield alpha equals original design exactly. Tier 2 remains independent.


## Current Tier 3 work
User approved Tier 2 and authorized Tier 3 on 2026-11-16. Same ctf_pillager.bbmodel now contains tier_1_recruit.png, tier_2_militia.png and tier_3_ranged_marksman.png; earlier two-tier limit superseded. Tier 1 and Tier 2 embedded PNGs byte-identical to the start of this Tier 3 task. Tier 3 is READY_FOR_USER_REVIEW: texture-only helmet on existing head, darker iron armor with retained highlights, extra shield metal cross-braces and corner reinforcements. Red field stays transparent; same shield visible extent. Physical 256×128, logical 128×64; 11 cubes, UV and authored animations preserved. Native front/back/three-quarter images reviewed; previews tier-3-front.png, tier-3-back.png, tier-3-three-quarter.png. No separate model file created. Next: user review of Tier 3.

Current Tier 3 head contract (supersedes prior head directions): keep a simple graded iron helmet over crown/brow, clean sides without separate panels, lights or ornaments; retain original red facial cheek tracers. Armor and shield unchanged by this head correction.

## Mandatory correction reminder — 2026-11-16

User explicitly rejects the latest Tier 3 armor finishing. It is NOT accepted or complete. Repeated procedural palette shifts, additional strips, bolts, flat inset panels and barely visible gradients did not satisfy the approved Tier 1 material standard. Do not repeat that correction direction without new visual evidence.

Before the next armor mutation: compare the actual mapped Tier 1 and Tier 3 at the same scale. Identify the missing material treatment on each affected plate (broad value masses, coherent stepped hue/value clusters, bevel, contact shadow, controlled reflection, edge finish). Detail must read on the model, not just in pixel counts or transaction receipts. Preserve clean reference plate topology; no generic decoration, checker noise, abstract patchwork, or flat single-colour strips. Complete adjoining front/back/side surfaces and verify no regression before reporting readiness. Never report "finished", "consistent" or "fully detailed" based only on a successful edit or save.

Current armor verdict: FAIL / awaiting a reference-grounded correction. User instruction to remember these requirements is standing project guidance, not approval of the current result.


Current correction checkpoint: prior generic badge removed. Tier 3 armor finishing now uses corresponding approved Tier 1 shoulder, breastplate, cuff, belt and knee material pixel clusters, adapted to existing Tier 3 plate masks and darker iron values. Front/back/three-quarter reviewed after activation; native saved PNG equals authored pixels. Head/helmet/facial red tracers/shield, Tier 1–2, geometry/UV and animation unchanged. Previous FAIL describes the superseded armor revision; current result is READY_FOR_USER_REVIEW, not user-approved. Current previews: tier-3-front.png, tier-3-back.png, tier-3-three-quarter.png.
