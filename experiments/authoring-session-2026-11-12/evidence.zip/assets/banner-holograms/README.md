# Banner holograms

Current Stage: REVIEW

## Standing

Authority: banner_post_hologram.bbmodel, accepted standing appearance. Separate native geometry, animation and PNG remain in this directory. 15 cubes, 8x8-unit centered pedestal, rest height32 units. Four short gradient rays; scanning behind original logo. Standing file was not overwritten during wall variant authoring.

## Wall variant

Authority: banner_hologram.bbmodel, saved through native Blockbench Save As before variant mutation. 15 cubes, overall rest bounds X=-9.2..9.2, Y=1.7..32.3, Z=-1.25..1.4. Mounting plane Z=1.4. Thin rear plate, top horizontal navy projector, silver clamps/trim, turquoise indicators and downward emitter. Same 15.24138x26 panel, original logo pixels and UV, scan behind logo. Four short parallel downward gradient rays, bright at emitter and fading toward panel; separate foreground carriers avoid coplanar panel overlap. One four-second looping Idle. Top emitter fixed; lower ray edge follows panel displacement; projection bridge height0.6 units, behind panel, overlap0.2 units; nominal panel/emitter clearance0.4 units (minimum0.26 during Idle). Front/side/top and authored pose samples0/1/3/4 reviewed; continuous native playback and Minecraft rendering remain UNVERIFIED.

Current outputs: banner_hologram.bbmodel, banner_hologram.png (lossless native embedded source), banner_hologram.geo.json, banner_hologram.animation.json. Geometry and animation retain the standing asset's inherited identifiers; these are alternative presentation files and must not be loaded concurrently under those same identifiers. The current MCP surface exposes no project-identifier/animation-rename operation. Unique simultaneous-pack identifiers remain an integration limitation; no claim of pack integration readiness.

Atlas preserves original logo and panel zones; wall housing faces packed immediately below logo/panel, with projection and scanning in the final effect row; obsolete islands cleared. Wall navy/steel material patches sampled from the saved standing pedestal PNG and transferred through MCP exact-pixel operations; obsolete pedestal UV islands cleared. Fractional UV density inherited from 1254px original atlas remains; layout hygiene is separate from strict integer-texel gate. Native/project files remain the authoring authority.
