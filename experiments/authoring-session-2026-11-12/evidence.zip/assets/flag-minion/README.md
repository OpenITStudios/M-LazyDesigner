# Flag Minion

Current Stage: ANIMATION
Status: READY_FOR_USER_REVIEW

## Authority
One canonical editable model: flag_minion.bbmodel, saved through native Blockbench Save.
Model identifier: flag_minion. 57 cubes, 15 bones, approximately 1.45 blocks tall.
Two embedded 256x256 textures: flag_minion_red.png and flag_minion_blue.png; one shared rig and UV layout. Color variants and approved geometry/texturing remain unchanged. ctf_golem remains separate and unchanged.

## Form and materials
Compact dual-blade robot based on reference.png. Pale neutral/lavender armor and dark gunmetal use stepped bevels, clustered highlights, shadows, seams, fasteners and wear detail. Red/blue energy variants share the same shading and alpha silhouette. No shield.

## Current animation inventory
- animation.flag_minion.walk: 1 second, loop. q.anim_time drives opposing leg phases, knee flex, swing-foot lift, foot orientation, body weight motion, counter-turning head and arms, and blade follow-through. In-place locomotion; caller controls movement speed.
- animation.flag_minion.hurt: 0.7333 seconds, once. Fast recoil, compressed knees, head/arm reaction, overshoot and recovery.
- animation.flag_minion.attack_slash_1: 1.3667 seconds, once. Alternating diagonal left/right slash combo with wind-up, torso torque and recovery.
- animation.flag_minion.attack_slash_2: 1.3 seconds, once. Simultaneous paired-blade sweep from a gathered preparation into a wide release; distinct from the alternating Slash 1 combo.
- animation.flag_minion.death: 5 seconds, hold. Stagger, knee buckle, accelerating fall, impact rebound, legs extending into a grounded prone pose, settling, pause and gradual sinking below the ground. Blades are held above the contact plane rather than propping up the body.

All action clips use the existing articulated rig, including head, torso, upper/lower arms, wrists/blades, thighs, shins and feet. Weapons remain attached. No geometry or texture changes were made during this animation stage. No Idle or shield clips were added to the latest requested five-clip inventory.

## Deliverables and evidence
flag_minion.bbmodel: NATIVE_SAVED; contains both variants and five clips.
flag_minion.animation.json: EXPORTED using native Bedrock AnimationCodec; JSON parsed, clip names checked against the editable model.
Walk played for over two cycles. Hurt, both attacks and Death played through in native Blockbench.
Representative front/side/back/three-quarter action poses reviewed. Death root height lowered by 1.2 model units during final settling and sinking, ramped from 0.9333 to 1.5 seconds per user correction to remove the perceived hover. Side poses and full playback rechecked. Revised Death and Slash 2 replayed through in Blockbench. Molang syntax valid; no unknown math functions, dangling bone animators or keys beyond clip length in diagnostics.
These checks are authoring evidence, not a physics simulation or exhaustive continuous collision proof.
Minecraft runtime and external activation/blending/speed matching: UNVERIFIED; no gameplay wiring requested.

Next: user review of the five animations. Animation is not claimed user-approved.
