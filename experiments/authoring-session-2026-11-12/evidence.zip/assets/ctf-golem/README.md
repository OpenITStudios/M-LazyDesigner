# CTF Golem

Current Stage: FINALIZATION — USER APPROVED / SAVED

Authority: ctf_golem.bbmodel, saved natively through LazyDesigner. Companion texture: ctf_golem.png, 256×256. Native Bedrock AnimationCodec export: ctf_golem.animation.json. No Minecraft gameplay/client-entity binding is included or verified.

## Model and texture
Height 40 units (2.5 blocks), shoulder/body envelope about26 units. Purple gunmetal, pale lavender armor and graded violet/magenta energy; no logos. Current model:67 cubes and15 bones. Three functional hand pieces form fingers/knuckles/thumb around the centered hammer shaft. Two ankle bones own the boot/toe/ankle-plate cohorts, enabling knee motion with flat foot contact.

Atlas retains original island pixel dimensions without whole-atlas downsampling. Nine repeated mechanical top/underside regions share related same-sized artwork. Remaining material runs received stepped longitudinal grading, bevel highlights and contact shadows. Original 256 layout and material palette remain; new grip pieces reuse existing mapped fist material.

## Animation inventory
- animation.ctf_golem.idle —4s loop; Molang breathing, knee flex, ankle counter-motion and root-height compensation. Feet stay planted.
- animation.ctf_golem.walk —1.2s loop; Molang opposing leg phases, swing clearance, ankle stabilization and delayed hammer-arm follow-through. In-place locomotion.
- animation.ctf_golem.attack_overhead —2.1s once; raised hammer anticipation, fast downward strike, follow-through and recovery.
- animation.ctf_golem.attack_sweep —2.2667s once; torso wind-up and side sweep. Wind-up path adjusted away from deployed guard.
- animation.ctf_golem.death —6s, hold last frame; accelerating forward collapse, contact/rebound, settling, then sinking from about2.65s. Disappearance relies on moving below an opaque ground surface, not unsupported bone-opacity animation.
- animation.ctf_golem.shield_on —0.8s, hold last frame; smoothstep Molang deployment clamps after0.65s.
- animation.ctf_golem.shield_off —0.7s once; reverse smoothstep to relaxed position.
- animation.ctf_golem.hurt —0.7s once; short recoil, knee compression, head lag and recovery.

## Layer contract
Select Idle OR Walk as locomotion. Shield On/Off own ONLY arm_right, forearm_right and shield. They do not reset preceding animation; the shield uses entity-relative rotation to maintain its protective plane. Base locomotion, Attack and Hurt do not key the right arm, so Guard can remain active during these clips. Apply Guard after locomotion/action. On and Off are mutually exclusive; Off replaces On. Death is exclusive and overrides previous animation. Switching/activation belongs to the external caller; no invented gameplay queries or add-on wiring.

Shield deployment is lowered toward torso/player-height coverage rather than held above the head. The final right-arm target is [25,55,-5], forearm [5,0,0], with an entity-facing shield. Artist-facing poses are native Blockbench evidence, not in-game combat/hitbox proof.

## Verification
Native playback: revised Idle >8s, Walk >2.4s, both attacks, full Death, Shield On/Off and Hurt. Representative front/side/three-quarter poses checked. Bounded composed-pose checks covered Guard+Walk and Guard+both attacks; temporary review clips were removed. All8 final clips have valid Molang syntax, zero unknown math functions, zero keys beyond clip length and zero dangling bone references. Native save/export names and bone references agree. Rest geometry and grip reviewed; current UV gate was ready after grip reuse.

Minecraft runtime, actual locomotion speed matching, gameplay state transitions and material/client bindings remain unverified. Native model_identifier is ctf_golem; native-exported geometry identifier is geometry.ctf_golem. Model was reopened and saved through Blockbench after the naming change.

Next: start the next model from its new reference; this asset is preserved as the approved style benchmark.

## Reuse for subsequent models
Work without Computer Use, through LazyDesigner MCP. Follow Geometry → UV → Texturing → Animation; inspect live identity, dimensions, hierarchy, textures and UV before coordinates. Match the supplied reference and explicit dimensions; keep purposeful cuboids, physical attachment, symmetry/centering, useful pivots and clearances, and eliminate coplanar flicker. Detail every exposed side to the same standard as the front, including rear/side/underside and held equipment. Use deliberate Minecraft pixel clusters, stepped hue/value grading, bevel highlights, contact shadows, material variation, restrained wear and fasteners; avoid flat single-color runs and excessive neon. Preserve reference colors and the agreed material language; do not automatically recolor later references. Prefer a compact 256 atlas with exact/mirrored material reuse and gutters; preserve identity-critical texel detail rather than downsampling the whole sheet. Use math for causal Idle/Walk cycles, planted-foot compensation, anticipation/action/follow-through/recovery, stable grips and loop seams. Keep shield/other overlays scoped to their own bones so they compose with locomotion and attacks. Verify mapped front/back/side/top and relevant animation extremes, including combined states; distinguish Blockbench proof from unverified in-game integration.

Outputs: ctf_golem.bbmodel (native saved), ctf_golem.png (256×256), ctf_golem.animation.json (8 native-exported clips), ctf_golem.geo.json (native geometry export). The previous sci-fi-guardian folder is a pre-rename checkpoint only.
