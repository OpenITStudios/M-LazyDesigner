# CTF Merchant

Current Stage: ANIMATION
Status: READY_FOR_USER_REVIEW
Geometry and final Minion-based texture styling: user-approved. One canonical ctf_merchant.bbmodel with49 cubes,11 bones, two embedded256x256 color variants. Height28.8 units. Current user-restored UV state preserved; earlier semantic UV repack was undone by the user and is not current authority.

## Materials
Blue is approved material authority. Red has matching steel/gunmetal detail with red energy and hologram. Red rebuilt from the approved blue pixel values with hue-channel permutation only on blue accent pixels; no old-red accent pixels reused. Shape, intensity distribution, detail and alpha follow blue exactly. Non-accent pixel mismatch count verified zero. Companion PNGs regenerated from saved embedded sources. Native texture variants share one model and animation.

## Idle
animation.ctf_merchant.idle:4-second loop,30fps snapping, q.anim_time-driven math. Gentle body balance over the stationary wheel, counter-moving head, delayed upper/lower arm and hand movement, subtle hovering hologram. Existing pivots and attachments reused. Wheel floor contact remains unchanged; no root translation or wheel rocking added. Start/end math phase identical.

## Deliverables and proof
ctf_merchant.bbmodel: native saved, contains both variants and one Idle.
ctf_merchant.animation.json: native Bedrock AnimationCodec export, parsed.
Idle played for more than two cycles in Blockbench. Opposite extreme front-three-quarter and side poses reviewed. Diagnostics: no dangling bone animators, no out-of-length keys, valid Molang syntax and recognized math functions. This is authored motion, not physics simulation. Minecraft runtime and external animation activation remain unverified.

Next: user review of Idle. No additional clips requested.
