# Pre-rename checkpoint

The approved model was renamed to flag_minion and has red/blue variants.
Canonical current handoff: ../flag-minion/README.md
