# Pre-rename checkpoint

This folder is preserved as a checkpoint. The approved current asset was renamed to ctf_golem.

Canonical model and current authoring/style handoff: ../ctf-golem/README.md
