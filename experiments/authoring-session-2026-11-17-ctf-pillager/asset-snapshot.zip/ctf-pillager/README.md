# CTF Pillager

Current Stage: FINALIZATION
Status: LOSSLESS_OPTIMIZATION_COMPLETE for requested files. Visual design and motion were approved by the user; Minecraft effects/runtime proof remains unverified.

## Authority and active project

The authoritative editable file is ctf_pillager.bbmodel in this directory, with active project UUID 7f045e0b-c98d-8bf9-31ac-4b4e6546b906. Work stayed in the same project and path. Current counts: 21 Cubes, 13 Groups, 2 Locators, 8 textures, 14 animation clips. Atlases remain 256×256 physical / 128×128 logical UV.

## Current texture files

- tier_1_recruit.png
- tier_2_militia.png
- tier_3_soldier.png
- tier_4_veteran.png
- tier_3_ranged_marksman.png
- tier_4_ranged_sharpshooter.png
- tier_5_champion.png
- tier_special_tnt.png

The eight external PNGs and embedded PNGs are synchronized from the latest native project pixels. Lossless optimization preserves every RGBA byte, including hidden RGB and partial alpha. Five textures use an exact indexed palette; the remaining three retain RGBA8. All UVs, UUIDs, geometry, timing, key values and Molang expressions remain unchanged.

## Current motion

- animation.ctf_pillager.walk (1.32 s, loop)
- animation.ctf_pillager.shield_on (0.05 s, hold)
- animation.ctf_pillager.shield_off (0.05 s, hold)
- animation.ctf_pillager.slash_1 (0.5 s, once)
- animation.ctf_pillager.slash_2 (0.5 s, once)
- animation.ctf_pillager.hurt (0.42 s, once)
- animation.ctf_pillager.eat_apple (1.84 s, once)
- animation.ctf_pillager.shield_bash (0.5 s, once)
- animation.ctf_pillager.death_backward (4.4 s, hold)
- animation.ctf_pillager.death_forward (4.4 s, hold)
- animation.ctf_pillager.shooting_arrow (1.9 s, once)
- animation.ctf_pillager.tnt_run (0.72 s, loop)
- animation.ctf_pillager.tnt_place (5.2 s, hold)
- animation.ctf_pillager.tnt_death (4.4 s, hold)

TNT special has no weapon. Run uses raised responsive hands and body counter-motion. Place lands at 0.65 s with local 16×16×16 TNT bounds [-8,0,-24]–[8,16,-8], then character digs downward. Explosion event is at 4.65 s, exactly four seconds after placement. TNT death reuses death_forward timing, falls face-first, rolls the TNT approximately nine units with ground contact, then sinks. Hold-channel final keys were corrected to linear; the last full scan found zero smooth terminal hold keys. Current motion evidence: animation-review/tnt/verification.json. Sampled native-frame GIFs are in animation-review/tnt/.

## Requested optimized outputs

- ctf_pillager.bbmodel: saved natively first, then only embedded PNG encoding optimized at the same path; complete non-bitmap data equality verified.
- Eight texture PNGs: decoded RGBA identical to latest native state.
- ctf_pillager.animation.json and particles/*.json: JSON compacted with parsed values identical.
- textures/particle/particles.png: losslessly optimized.
- ctf_pillager_optimized.zip: 13 current asset files, archive CRC and exact byte roundtrip verified. Existing .geo.json exports are historical and deliberately excluded.

Optimization proof and sizes: texture-redesign/lossless-optimization/verification.json. The reusable optimizer is optimize.py in that directory.

## Save behavior and proof limits

PNG byte compression was applied to files after native Save; it does not alter editor pixels or motion. Blockbench regenerates embedded PNG bytes during a later native Save, so rerun the optimizer afterward to retain these file sizes. No project was reopened or switched.

Smoke/explosion JSON assets and animation effect events exist, but particle/sound rendering in the editor and Minecraft has not been verified. World-grid placement and destructive explosion behavior require external gameplay integration. Static/sample capture proof does not claim a Minecraft/controller test. Historic recovery/reference files remain untouched and are not current deliverables.
