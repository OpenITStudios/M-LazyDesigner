import base64
import hashlib
import io
import json
import struct
import zlib
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)


def filtered_candidates(raw, bpp):
    a = np.asarray(raw, dtype=np.uint8)
    prev = np.vstack([np.zeros((1, a.shape[1]), dtype=np.uint8), a[:-1]])
    left = np.zeros_like(a)
    left[:, bpp:] = a[:, :-bpp]
    upper_left = np.zeros_like(a)
    upper_left[:, bpp:] = prev[:, :-bpp]
    li, up, ul = left.astype(np.int32), prev.astype(np.int32), upper_left.astype(np.int32)
    p = li + up - ul
    pa, pb, pc = abs(p - li), abs(p - up), abs(p - ul)
    predictor = np.where((pa <= pb) & (pa <= pc), li, np.where(pb <= pc, up, ul))
    filters = np.stack([a, a - left, a - prev, (a.astype(np.int32) - ((li + up) // 2)).astype(np.uint8), (a.astype(np.int32) - predictor).astype(np.uint8)])
    signed = filters.astype(np.int16)
    cost = np.abs(np.where(signed > 127, signed - 256, signed)).sum(axis=2)
    adaptive = cost.argmin(axis=0)
    rows = np.arange(a.shape[0])
    yield np.column_stack([adaptive.astype(np.uint8), filters[adaptive, rows]]).tobytes()
    for i in range(5):
        yield np.column_stack([np.full(a.shape[0], i, dtype=np.uint8), filters[i]]).tobytes()


def make_candidates(raw, width, height, color_type, palette=b'', alpha=b''):
    prefix = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, color_type, 0, 0, 0))
    if palette:
        prefix += chunk(b'PLTE', palette)
    if alpha:
        prefix += chunk(b'tRNS', alpha)
    for filtered in filtered_candidates(raw, 1 if color_type == 3 else 4):
        for strategy in (zlib.Z_DEFAULT_STRATEGY, zlib.Z_FILTERED, zlib.Z_RLE, zlib.Z_HUFFMAN_ONLY):
            compressor = zlib.compressobj(9, zlib.DEFLATED, 15, 9, strategy)
            packed = compressor.compress(filtered) + compressor.flush()
            yield prefix + chunk(b'IDAT', packed) + chunk(b'IEND', b'')


def optimize_png(data):
    image = Image.open(io.BytesIO(data)).convert('RGBA')
    pixels = image.tobytes()
    width, height = image.size
    rgba = np.asarray(image, dtype=np.uint8)
    candidates = [(data, 'original')]
    candidates.extend((b, 'rgba8') for b in make_candidates(rgba.reshape(height, width * 4), width, height, 6))
    colors, first, inverse, counts = np.unique(rgba.reshape(-1, 4), axis=0, return_index=True, return_inverse=True, return_counts=True)
    if len(colors) <= 256:
        for order in (np.arange(len(colors)), np.argsort(first), np.argsort(-counts)):
            remap = np.empty(len(colors), dtype=np.uint8)
            remap[order] = np.arange(len(colors), dtype=np.uint8)
            indices = remap[inverse].reshape(height, width)
            palette = colors[order, :3].tobytes()
            alpha = colors[order, 3].tobytes().rstrip(b'\xff')
            candidates.extend((b, 'indexed8_exact') for b in make_candidates(indices, width, height, 3, palette, alpha))
    result, mode = min(candidates, key=lambda pair: len(pair[0]))
    decoded = Image.open(io.BytesIO(result)).convert('RGBA')
    assert decoded.size == image.size and decoded.tobytes() == pixels, 'RGBA mismatch'
    return result, {'mode': mode, 'unique_rgba': len(colors), 'rgba_sha256': hashlib.sha256(pixels).hexdigest(), 'before_bytes': len(data), 'after_bytes': len(result), 'width': width, 'height': height}


def main():
    model_path = ROOT / 'ctf_pillager.bbmodel'
    original_text = model_path.read_text(encoding='utf-8')
    before = json.loads(original_text)
    model = json.loads(original_text)
    report = {'textures': [], 'json': []}
    for texture in model['textures']:
        source = base64.b64decode(texture['source'].split(',', 1)[1])
        result, entry = optimize_png(source)
        external = ROOT / texture['name']
        entry.update(name=texture['name'], uuid=texture['uuid'], external_before_bytes=external.stat().st_size if external.exists() else None)
        external.write_bytes(result)
        texture['source'] = 'data:image/png;base64,' + base64.b64encode(result).decode('ascii')
        report['textures'].append(entry)
    # Only encoded bitmap bytes change inside the editable model.
    comparison = json.loads(json.dumps(model))
    for a, b in zip(comparison['textures'], before['textures']):
        a['source'] = b['source']
    assert comparison == before, 'Non-bitmap model data changed'
    model_bytes = json.dumps(model, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    assert json.loads(model_bytes) == model
    model_path.write_bytes(model_bytes)
    report['model'] = {'before_bytes': len(original_text.encode('utf-8')), 'after_bytes': len(model_bytes), 'non_bitmap_data_unchanged': True}
    for path in [ROOT / 'ctf_pillager.animation.json', *sorted((ROOT / 'particles').glob('*.json'))]:
        old = path.read_bytes()
        obj = json.loads(old)
        new = json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        assert json.loads(new) == obj
        if len(new) < len(old):
            path.write_bytes(new)
        report['json'].append({'name': str(path.relative_to(ROOT)), 'before_bytes': len(old), 'after_bytes': path.stat().st_size, 'parsed_data_unchanged': True})
    particle_texture = ROOT / 'textures' / 'particle' / 'particles.png'
    if particle_texture.exists():
        result, entry = optimize_png(particle_texture.read_bytes())
        particle_texture.write_bytes(result)
        entry['name'] = str(particle_texture.relative_to(ROOT))
        report['particle_texture'] = entry
    report['verification'] = 'Exact decoded RGBA equality for all PNGs; full non-bitmap model equality; parsed JSON equality.'
    (OUT / 'verification.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
