# citadel-caster

Editable source: `source/citadel_caster.bbmodel`. Geometry: `models/entity/citadel_caster.geo.json` (`geometry.citadel.caster`).

Animation: `animations/citadel_caster.animation.json`.

Texture variants are in `textures/entity/`; `asset.json` lists exact IDs, dimensions, locator coordinates and hashes. Source textures are embedded and match exported PNGs.

Bind the client entity, render controller, texture selection, animation activation and gameplay logic in the target project. This folder contains development components; no Minecraft runtime integration is claimed.
