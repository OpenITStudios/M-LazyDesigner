# citadel-camp

Editable source: `source/citadel_camp.bbmodel`. Geometry: `models/entity/citadel_camp.geo.json` (`geometry.citadel.camp`).

Animation: `animations/citadel_camp.animation.json`.

Texture variants are in `textures/entity/`; `asset.json` lists exact IDs, dimensions, locator coordinates and hashes. Source textures are embedded and match exported PNGs.

Bind the client entity, render controller, texture selection, animation activation and gameplay logic in the target project. This folder contains development components; no Minecraft runtime integration is claimed.
