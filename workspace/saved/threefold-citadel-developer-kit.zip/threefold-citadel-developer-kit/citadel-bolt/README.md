# citadel-bolt

Editable source: `source/citadel_bolt.bbmodel`. Geometry: `models/entity/citadel_bolt.geo.json` (`geometry.citadel.bolt`).

Animation: `animations/citadel_bolt.animation.json`.

Texture variants are in `textures/entity/`; `asset.json` lists exact IDs, dimensions, locator coordinates and hashes. Source textures are embedded and match exported PNGs.

Bind the client entity, render controller, texture selection, animation activation and gameplay logic in the target project. This folder contains development components; no Minecraft runtime integration is claimed.
