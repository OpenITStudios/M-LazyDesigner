# citadel-sentinel

Editable source: `source/citadel_sentinel.bbmodel`. Geometry: `models/entity/citadel_sentinel.geo.json` (`geometry.citadel.sentinel`).

Animation: `animations/citadel_sentinel.animation.json`.

Texture variants are in `textures/entity/`; `asset.json` lists exact IDs, dimensions, locator coordinates and hashes. Source textures are embedded and match exported PNGs.

Bind the client entity, render controller, texture selection, animation activation and gameplay logic in the target project. This folder contains development components; no Minecraft runtime integration is claimed.
