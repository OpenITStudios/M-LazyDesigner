# citadel-core

Editable source: `source/citadel_core.bbmodel`. Geometry: `models/entity/citadel_core.geo.json` (`geometry.citadel.core`).

Animation: `animations/citadel_core.animation.json`.

Texture variants are in `textures/entity/`; `asset.json` lists exact IDs, dimensions, locator coordinates and hashes. Source textures are embedded and match exported PNGs.

Bind the client entity, render controller, texture selection, animation activation and gameplay logic in the target project. This folder contains development components; no Minecraft runtime integration is claimed.
