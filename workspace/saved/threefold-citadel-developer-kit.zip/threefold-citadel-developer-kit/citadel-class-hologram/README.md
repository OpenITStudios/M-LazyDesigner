# Class Holograms

Five Snowstorm particle effects: Duelist, Warden, Ranger, Arcanist and Luminary. Identifiers are `citadel:class_hologram_<class>`.

Import a file from `particles/` into Snowstorm, then load its matching original PNG from `textures/particle/`. Upright camera-facing 1.5 x 1.5-block billboard; one persistent particle, subtle 6-second vertical bob, no rotation.

For Bedrock development, copy the particles and textures into your resource pack preserving relative paths. Local position supports following an attached emitter. The external caller owns placement, activation and emitter removal. No standalone manifest is included because this is the combined development-components kit, not an installable pack. Minecraft runtime untested.
