# citadel-guardian-statue

Editable source: `source/citadel_guardian_statue.bbmodel`. Geometry: `models/entity/citadel_guardian_statue.geo.json` (`geometry.citadel.guardian_statue`).

Static decoration; no animation file.

Texture variants are in `textures/entity/`; `asset.json` lists exact IDs, dimensions, locator coordinates and hashes. Source textures are embedded and match exported PNGs.

Bind the client entity, render controller, texture selection, animation activation and gameplay logic in the target project. This folder contains development components; no Minecraft runtime integration is claimed.
