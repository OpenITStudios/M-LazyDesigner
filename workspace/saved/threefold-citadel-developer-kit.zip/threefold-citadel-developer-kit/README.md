# Threefold Citadel Developer Kit

Contains 10 current editable Blockbench models, 10 native Bedrock geometry files, 9 animation files with 27 clips, 23 model texture variants, and 5 Snowstorm class holograms with their original PNGs.

Each model folder contains source/, models/entity/, textures/entity/, asset.json and a concise guide; animated models also include animations/. Guardian Statue is static. Class holograms use particles/ and textures/particle/. See catalog.json for the full inventory and checksums.sha256 for integrity.

Includes the latest Tower/Core keyframe reductions, stronger procedural jungle/boss idles, and the single-cube Ember/Azure Bolt with velocity-style visual flight.

This is a development-components delivery. Gameplay entities, controllers, material bindings, projectile trajectory, placement and resource/behavior pack manifests remain downstream integration work. Sources and exports are synchronized; Minecraft runtime testing has not been performed. Historical checkpoints, previews, scripts and recovery files are excluded.
